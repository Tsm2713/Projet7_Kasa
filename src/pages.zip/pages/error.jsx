import './error.scss';
export default Error;
