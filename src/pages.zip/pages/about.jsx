function About() {
  return (
    <div>
      À propos
    </div>
  );
}
export default About;
