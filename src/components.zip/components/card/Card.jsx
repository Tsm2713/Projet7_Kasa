import React from 'react';
import './Card.scss';

function Card() {
  return (
    <div className="card">
      <h2>Titre de la location</h2>
    </div>
  );
}

export default Card;
