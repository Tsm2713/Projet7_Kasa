/*import { Header } from "./header";
import { Banner } from "./banner";
import { Collapse } from "./collapse"
import { Tags } from "./tags";
import { Rating } from "./rating";
import { Carousel } from "./carousel";
import { Footer } from "./footer";

export { Header, Banner, Collapse, Tags, Rating, Carousel, Footer };*/